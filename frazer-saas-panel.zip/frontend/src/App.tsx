import { useState } from "react";

export default function App() {
  const [sessionId, setSessionId] = useState("");
  const [code, setCode] = useState("");

  async function createSession() {
    const res = await fetch("http://localhost:8000/api/session/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: "user1" })
    });

    const data = await res.json();
    setSessionId(data.id);

    setInterval(async () => {
      const r = await fetch(`http://localhost:8000/api/session/${data.id}`);
      const d = await r.json();
      if (d.code) setCode(d.code);
    }, 3000);
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Frazer SaaS Panel</h1>

      <button onClick={createSession}>
        Create Session
      </button>

      {sessionId && <p>Session: {sessionId}</p>}
      {code && <h2>Code: {code}</h2>}
    </div>
  );
}